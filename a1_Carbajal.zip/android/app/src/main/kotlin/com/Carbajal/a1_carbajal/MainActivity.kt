package com.Carbajal.a1_carbajal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
